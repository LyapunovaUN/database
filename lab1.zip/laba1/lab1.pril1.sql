
CREATE TABLE `products` (

  `product_id` INT NOT NULL AUTO_INCREMENT,

  `name` VARCHAR(255) NOT NULL,

  `vendor_code` VARCHAR(255) NOT NULL,

  PRIMARY KEY (`product_id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `inventory` (

  `inventory_id` INT NOT NULL AUTO_INCREMENT,

  `product_id` INT NOT NULL,

  `quantity` INT NOT NULL,
  
  `location` VARCHAR(255) NOT NULL,

  PRIMARY KEY (`inventory_id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Заполнение таблицы 'products'

INSERT INTO `products` (`name`, `vendor_code`) VALUES ('Ноутбук', 'HP');
INSERT INTO `products` (`name`, `vendor_code`) VALUES ('Мышь', 'AMD');
INSERT INTO `products` (`name`, `vendor_code`) VALUES ('Мышь', 'ACER');

-- Заполнение таблицы 'inventory'

INSERT INTO `inventory` (`product_id`, `quantity`, `location`) VALUES (1, 93, 'Секция C-1');
INSERT INTO `inventory` (`product_id`, `quantity`, `location`) VALUES (1, 38, 'Комната хранения');
INSERT INTO `inventory` (`product_id`, `quantity`, `location`) VALUES (2, 44, 'Временное хранение');
INSERT INTO `inventory` (`product_id`, `quantity`, `location`) VALUES (3, 76, 'Секция C-2');
INSERT INTO `inventory` (`product_id`, `quantity`, `location`) VALUES (1, 10, 'Временное хранение');


SELECT *
FROM `inventory` 
WHERE `quantity` > 50;